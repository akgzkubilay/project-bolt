import { Observable } from '@nativescript/core';
import { BluetoothService } from './services/bluetooth.service';
import { AudioRecorderService } from './services/audio-recorder.service';

export class MainViewModel extends Observable {
  private bluetoothService: BluetoothService;
  private audioRecorderService: AudioRecorderService;
  
  private _devices: any[] = [];
  private _recordings: any[] = [];
  private _isRecording: boolean = false;
  private _isDeviceConnected: boolean = false;
  private _connectionStatus: string = 'No device connected';
  private _recordingStatus: string = '';

  constructor() {
    super();
    this.bluetoothService = new BluetoothService();
    this.audioRecorderService = new AudioRecorderService();
    this.loadRecordings();
  }

  async scanDevices() {
    try {
      if (!await this.bluetoothService.isBluetoothEnabled()) {
        await this.bluetoothService.requestBluetoothEnable();
      }
      
      this.set('devices', []);
      const devices = await this.bluetoothService.startScanning();
      this.set('devices', devices);
    } catch (error) {
      console.error('Scan error:', error);
      this.set('connectionStatus', 'Error scanning devices');
    }
  }

  async onDeviceSelect(args) {
    const device = this._devices[args.index];
    try {
      await this.bluetoothService.connect(device.UUID);
      this._isDeviceConnected = true;
      this.set('connectionStatus', `Connected to ${device.name}`);
      this.notifyPropertyChange('isDeviceConnected', true);
    } catch (error) {
      console.error('Connection error:', error);
      this.set('connectionStatus', 'Error connecting to device');
    }
  }

  async toggleRecording() {
    if (!this._isRecording) {
      try {
        const filename = `recording_${Date.now()}`;
        await this.audioRecorderService.startRecording(filename);
        this._isRecording = true;
        this.set('recordingStatus', 'Recording...');
      } catch (error) {
        console.error('Recording error:', error);
        this.set('recordingStatus', 'Error starting recording');
      }
    } else {
      try {
        await this.audioRecorderService.stopRecording();
        this._isRecording = false;
        this.set('recordingStatus', 'Recording stopped');
        await this.loadRecordings();
      } catch (error) {
        console.error('Stop recording error:', error);
        this.set('recordingStatus', 'Error stopping recording');
      }
    }
    this.notifyPropertyChange('isRecording', this._isRecording);
  }

  async loadRecordings() {
    try {
      const files = await this.audioRecorderService.getRecordings();
      this._recordings = files.map(file => ({
        name: file,
        date: new Date(file.split('_')[1].split('.')[0]).toLocaleString()
      }));
      this.notifyPropertyChange('recordings', this._recordings);
    } catch (error) {
      console.error('Error loading recordings:', error);
    }
  }

  get devices() {
    return this._devices;
  }

  get recordings() {
    return this._recordings;
  }

  get isRecording() {
    return this._isRecording;
  }

  get isDeviceConnected() {
    return this._isDeviceConnected;
  }

  get connectionStatus() {
    return this._connectionStatus;
  }

  get recordingStatus() {
    return this._recordingStatus;
  }
}