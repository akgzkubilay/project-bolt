import { AudioRecorder } from 'nativescript-audio-recorder';
import { knownFolders } from '@nativescript/core';

export class AudioRecorderService {
  private recorder: AudioRecorder;
  private recordingsFolder: string;

  constructor() {
    this.recorder = new AudioRecorder();
    this.recordingsFolder = knownFolders.documents().getFolder('recordings').path;
  }

  async startRecording(filename: string): Promise<void> {
    try {
      const filePath = `${this.recordingsFolder}/${filename}.wav`;
      await this.recorder.start({
        filename: filePath,
        format: 'wav',
        sampleRate: 44100,
        channels: 1
      });
    } catch (error) {
      console.error('Error starting recording:', error);
      throw error;
    }
  }

  async stopRecording(): Promise<string> {
    try {
      const filePath = await this.recorder.stop();
      return filePath;
    } catch (error) {
      console.error('Error stopping recording:', error);
      throw error;
    }
  }

  async getRecordings(): Promise<string[]> {
    const folder = knownFolders.documents().getFolder('recordings');
    return folder.getEntities();
  }
}