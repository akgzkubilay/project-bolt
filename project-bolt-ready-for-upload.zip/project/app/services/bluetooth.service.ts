import { Bluetooth } from '@nativescript/bluetooth';

export class BluetoothService {
  private bluetooth: Bluetooth;
  
  constructor() {
    this.bluetooth = new Bluetooth();
  }

  async isBluetoothEnabled(): Promise<boolean> {
    return await this.bluetooth.isBluetoothEnabled();
  }

  async requestBluetoothEnable(): Promise<void> {
    try {
      await this.bluetooth.enable();
    } catch (error) {
      console.error('Error enabling bluetooth:', error);
      throw error;
    }
  }

  async startScanning(seconds: number = 4): Promise<any[]> {
    const devices = [];
    return new Promise((resolve, reject) => {
      this.bluetooth.startScanning({
        seconds,
        onDiscovered: (peripheral) => {
          devices.push(peripheral);
        },
        onError: (err) => {
          reject(err);
        }
      }).then(() => {
        resolve(devices);
      });
    });
  }

  async connect(UUID: string): Promise<void> {
    try {
      await this.bluetooth.connect({
        UUID,
        onConnected: (peripheral) => {
          console.log('Connected to device:', peripheral.UUID);
        },
        onDisconnected: (peripheral) => {
          console.log('Disconnected from device:', peripheral.UUID);
        }
      });
    } catch (error) {
      console.error('Error connecting to device:', error);
      throw error;
    }
  }
}